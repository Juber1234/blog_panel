<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AuthMiddleware {

    private $CI;

    public function __construct() {
        $this->CI =& get_instance();
        $this->CI->load->library('session');
        $this->CI->load->helper('url');

    }

    public function check_auth() {
        // die("juber");
        // Check if the user is not logged in
        if (!$this->CI->session->userdata('user') &&  !in_array($this->CI->uri->segment(1), ['login', 'index']) ) {
            // echo "Directly not authorized.";die;
            redirect(base_url()."login");die;
        }
    }
}
