<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends MY_Controller {

	function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));
		$this->load->database();
		$this->load->library('session');
		$this->load->library('upload');



    }
	public function index()
	{

		
		$input = $this->input->post();
		if($input){
			$this->form_validation->set_rules('name','Username','trim|required');
			$this->form_validation->set_rules('email','Email','trim|required|valid_email');
			$this->form_validation->set_rules('roll_number','Roll Number','trim|required|numeric');
			$this->form_validation->set_rules('password', 'Password', 'trim|required|exact_length[8]', array(
				'exact_length' => 'The password must be exactly 8 characters long.'
			));
			$this->form_validation->set_rules('conf_password','Confirm Password','trim|required|matches[password]');
			if($this->form_validation->run() == true)
			{
				$data = [
					'name'=>$input['name'],
					'email'=>$input['email'],
					'roll_number'=>$input['roll_number'],
					'password'=> password_hash($input['password'], PASSWORD_DEFAULT)
				];
				$res = $this->db->insert('students',$data);
				if($res){
					redirect(base_url()."login");

				}
			}
		}

		$this->load->view('register');
	}

	public function login()
	{
		$input = $this->input->post();
		$data['error'] = '';
		if($input){
			$this->form_validation->set_rules('roll_number','Roll Number','trim|required|numeric');
			$this->form_validation->set_rules('password', 'Password', 'trim|required|exact_length[8]', array(
				'exact_length' => 'The password must be exactly 8 characters long.'
			));
			if($this->form_validation->run() == true)
			{
               $data = $this->db->get_where('students',['roll_number'=>$input['roll_number']])->row_array();
			   if($data){
					// Verify the entered password with the hashed password from the database
					if (password_verify($input['password'], $data['password'])) {
						unset($data['password']);
						$this->session->set_userdata('user',$data);
                        redirect(base_url()."blog");
					} else {
						$data['error'] = 'Invalid Credentials';

					}
				} else {
					$data['error'] = 'Invalid Credentials.';
				
			   }

			}
		}

		$this->load->view('login',$data);
	}

	public function blog() {
	  $input= $this->input->post();
	  $ro_num = $_SESSION['user'];
	  if($input && $_FILES){
		$this->form_validation->set_rules('title', 'Title', 'trim|required');
		$this->form_validation->set_rules('description', 'Description', 'trim|required');
		if ($this->form_validation->run() == true) {
			if (!empty($_FILES['image']['name'])) {
				$config['upload_path'] = './upload_image'; 
				$config['allowed_types'] = 'gif|jpg|jpeg|png';
				$config['max_size'] = 50000; 
				$this->upload->initialize($config);
				if (!$this->upload->do_upload('image')) {
					$error = $this->upload->display_errors();
					echo json_encode($error);die;
				} else {
					$data = $this->upload->data();

					$input['image'] = $data['file_name'];
					$input['roll_num'] = $ro_num['roll_number'];
					$this->db->insert('blog',$input);
					echo "blog insert successfully";die;
				}
			} else {
				echo "plesae upload image";die;
				
			}
	
		}
	}
	     $data['data'] = $this->db->get_where('blog',['roll_num'=>$ro_num['roll_number']])->result();
	
		$this->load->view('blog',$data);
	}

	public function logout(){
		$this->session->unset_userdata('user');
        $this->session->sess_destroy();
		echo json_encode(['url'=>base_url()."login"]);
        // redirect(base_url()."login");
	}

	
}
