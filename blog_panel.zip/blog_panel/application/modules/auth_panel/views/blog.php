<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  /* background-color: black; */
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.addBlog {
  background-color: #04AA6D;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}
.red{
   color:red;
}

.addBlog:hover {
  opacity: 1;
}

a {
  color: dodgerblue;
}





table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
</head>
<body>
 

<form  method="post" enctype='multipart/form-data' id="blog" class="py-3">
  <div class="container">
  <button class="btn btn-danger" id ="logout" style="margin-left: 90%">Logout</button>

  <div>
  <h1>Add Blog</h1>

</div>
   
   
    <hr>
    <!-- <label for="title"><b>Title</b></label> -->
    <input type="text" placeholder="Enter Title" name="title" id="title" required >
    <sapn class="red"><?php echo form_error('title'); ?></span>

    <!-- <label for="description"><b>Description</b></label> -->
    <input type="text" placeholder="Enter Description" name="description" id="desc" required>
    <span class="red"><?php echo form_error('description'); ?></span>

    <!-- <label for="file"><b>Select Image</b></label> -->
    <input type="file"  name="image" id="image" required>
    <span class="red"><?php echo form_error('image'); ?></span>
    <hr>
    <div class="">
    <button type="submit" class="addBlog w-25">Add Blog</button>
</div>
  </div>

</form>
<div class="container">
  <div class="table-responsive">
<table class="juber" width="100%" border="0" cellspacing="5" cellpadding="5">
  <tr style="background:#CCC">
    <th>Id</th>
    <th>Title</th>
    <th>Description</th>
    <th>Image</th>
  </tr>
  <?php
//   $i=1;
  foreach($data as $row)
  {
  echo "<tr>";
  echo "<td>".$row->id."</td>";
  echo "<td>".$row->title."</td>";
  echo "<td>".$row->description."</td>";
  echo "<td><img width=60px; height=50px src='" . base_url('upload_image/').$row->image . "' alt='Image'></td>";

  echo "</tr>";
//   $i++;
  }
   ?>
</table>
</div>
</div>

</body>
</html>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script> -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<script>
     $('#blog').on('submit',(function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                $.ajax({
                    type:'POST',
                    url: "<?= base_url();?>auth_panel/welcome/blog",
                    data:formData,
                    cache:false,
                    contentType: false,
                    processData: false,
                    success:function(data){
                      alert(data);
                      $('#title,#desc,#image').val("");
                      location.reload(true);
                        console.log(data);
                    },
                    error: function(data){
                        console.log("error");
                        console.log(data);
                    }
                });
            }));

            $('#logout').on('click',(function(e) {
                e.preventDefault();
                $.ajax({
                    type:'POST',
                    url: "<?= base_url();?>auth_panel/welcome/logout",
                    success:function(data){
                      var data = JSON.parse(data);
                      // console.log('juber',data.url);
                        location.href= data.url;
                    },
                    error: function(data){
                        console.log("error");
                        console.log("juber",data);
                    }
                });
            }));

</script>
